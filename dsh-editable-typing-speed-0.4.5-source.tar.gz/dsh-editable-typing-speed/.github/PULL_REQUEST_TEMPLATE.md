## 改了什么

<!-- 一句话说明 -->

## 为什么

<!-- 关联 issue、用户场景 -->

## 怎么验证的

- [ ] `node --test` 全绿
- [ ] `node scripts/verify-manifest.mjs` 通过
- [ ] 在真实 DSH 上手动验证（说明渠道与步骤）

## 检查清单

- [ ] 挂钩代码仍满足：幂等 / 自愈 / 失败即放行
- [ ] `lib/engine.js` 仍是纯函数（没有引入 Node API 或渠道 SDK）
- [ ] 用户可见文本为中文
- [ ] 若有行为变更，已更新 README 与 CHANGELOG
